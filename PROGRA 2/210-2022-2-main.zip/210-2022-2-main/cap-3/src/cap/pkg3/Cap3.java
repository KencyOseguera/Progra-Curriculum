/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cap.pkg3;


/**
 *
 * @author unah
 */
public class Cap3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Math.floor(5.6) = " + Math.floor(5.9));
        System.out.println("Math.ceil(5.1) = " + Math.ceil(5.1));
        
        System.out.println("Math.max(4, 7) = " + Math.max(4, 7));
        System.out.println("Math.min(4, 7) = " + Math.min(4, 7));
        
        System.out.println("Math.pow(2, 3) = " + Math.pow(2, 3));
        
        int x = (int)Math.pow(2, 3);
        System.out.println("x = " + x);
        
        System.out.println("random = " + Math.random());
        
        int random = (int)(Math.random() * 10 + 1);
        System.out.println(random);
    }
    
}


// Seguridad
