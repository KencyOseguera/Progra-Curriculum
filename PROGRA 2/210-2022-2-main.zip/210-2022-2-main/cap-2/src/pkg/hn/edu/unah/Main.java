/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg.hn.edu.unah;

/**
 *
 * @author unah
 */
public class Main {
    public static final float PI = 3.14159F;
    
    public static void mensaje() {
        System.out.println("Hola mundo");
    }
    
}
