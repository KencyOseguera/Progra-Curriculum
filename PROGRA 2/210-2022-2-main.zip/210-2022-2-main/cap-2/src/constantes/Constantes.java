/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package constantes;

/**
 *
 * @author unah
 */
public class Constantes {
    public static void main(String[] args) {
        int x = 10;
        
        x = 100;
        
        // Constantes
        final int Y;
        Y = 100;
        
        final int MES_ACTUAL = 6;
        final float ISV = 15.0f;
        
    }
            
}
